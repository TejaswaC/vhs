package com.cts.VehicleReservationSystem.configuration;

public class MyConstants {
	 
    // Replace with your email here:  
    public static final String MY_EMAIL = "tejasw22@gmail.com";
 
    // Replace password!!
    public static final String MY_PASSWORD = "hindustantimes!1";
 
    // And receiver!
    public static final String FRIEND_EMAIL = "tejasw22@gmail.com";
 
}